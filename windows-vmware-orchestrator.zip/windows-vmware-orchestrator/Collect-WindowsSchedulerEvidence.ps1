#requires -Version 5.1
<#
.SYNOPSIS
    Read-only Windows Server 2022 vs 2025 scheduler/CPU evidence collector.
.DESCRIPTION
    Samples every visible Windows thread and every visible process (including
    zero-switch processes), summarizes per-process context-switch rates by PID
    and by executable name, and captures OS, security, VMware driver, CPU and
    scheduler-related configuration evidence.

    Optional -TraceETW: WPR GeneralProfile trace for *why* threads switch.
    This script makes no configuration changes and does not stop any process.

    Run elevated on BOTH VMs while the SAME benchmark stage is active.
    Use a quiet baseline run separately if desired.
.EXAMPLE
    .\Collect-WindowsSchedulerEvidence.ps1 -Label WS2022-Test1 -Samples 30 -IntervalSeconds 2
.EXAMPLE
    .\Collect-WindowsSchedulerEvidence.ps1 -Label WS2025-Test1 -Samples 30 -IntervalSeconds 2 -TraceETW
#>
[CmdletBinding()]
param(
    [ValidateRange(2,10000)][int]$Samples = 30,
    [ValidateRange(1,300)][int]$IntervalSeconds = 2,
    [ValidatePattern('^[A-Za-z0-9_.-]+$')][string]$Label = 'LoadTest',
    [string]$OutputRoot = 'C:\SchedulerEvidence',
    [switch]$TraceETW,
    [switch]$NoZip
)

$ErrorActionPreference = 'Stop'
$runId = '{0}_{1}_{2}' -f $env:COMPUTERNAME,$Label,(Get-Date -Format 'yyyyMMdd_HHmmss')
$folder = Join-Path $OutputRoot $runId
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$errorsFile = Join-Path $folder 'Warnings.txt'
$threadCsv = Join-Path $folder 'Thread_Samples_All.csv'
$procCsv   = Join-Path $folder 'Process_Samples_All.csv'
$nameCsv   = Join-Path $folder 'ProcessName_Samples_All.csv'
$sysCsv    = Join-Path $folder 'System_Samples.csv'
$cpuCsv    = Join-Path $folder 'Processor_Samples_PerCPU.csv'
$etwFile   = Join-Path $folder 'Scheduler_Trace.etl'

function Warn-Collector([string]$where, [string]$message) {
    $entry = ('{0:u} [{1}] {2}' -f (Get-Date),$where,$message)
    Add-Content -LiteralPath $errorsFile -Value $entry
    Write-Warning $entry
}
function Capture-Json([string]$name, [scriptblock]$block) {
    try {
        $result = & $block
        $result | ConvertTo-Json -Depth 8 | Out-File -LiteralPath (Join-Path $folder ($name + '.json')) -Encoding UTF8
    } catch { Warn-Collector $name $_.Exception.Message }
}
function Capture-Text([string]$name, [scriptblock]$block) {
    try {
        (& $block 2>&1 | Out-String) | Out-File -LiteralPath (Join-Path $folder ($name + '.txt')) -Encoding UTF8
    } catch { Warn-Collector $name $_.Exception.Message }
}
function Export-Rows([object[]]$rows,[string]$destination) {
    if ($rows.Count -eq 0) { return }
    if (Test-Path -LiteralPath $destination) {
        $rows | Export-Csv -LiteralPath $destination -NoTypeInformation -Append -Encoding UTF8
    } else {
        $rows | Export-Csv -LiteralPath $destination -NoTypeInformation -Encoding UTF8
    }
}
function Read-Processes {
    @(Get-CimInstance -ClassName Win32_Process |
       Select-Object ProcessId, ParentProcessId, Name, CreationDate,
           ExecutablePath, Priority, ThreadCount)
}
function N([object]$value) {
    if ($null -eq $value -or "$value" -eq '') { return 0.0 }
    return [double]$value
}
function Save-Inventories {
    Write-Host 'Collecting host and scheduler inventory...'
    Capture-Json 'OperatingSystem' { Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber, OSArchitecture, LastBootUpTime, InstallDate }
    Capture-Json 'ComputerSystem' { Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer,Model,NumberOfLogicalProcessors,NumberOfProcessors,TotalPhysicalMemory,HypervisorPresent }
    Capture-Json 'CPU_Topology' { Get-CimInstance Win32_Processor | Select-Object DeviceID,Name,Manufacturer,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,CurrentClockSpeed,ProcessorId }
    Capture-Json 'BIOS' { Get-CimInstance Win32_BIOS | Select-Object Manufacturer,SMBIOSBIOSVersion,ReleaseDate,SerialNumber }
    Capture-Json 'OS_Build_UBR' { Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' | Select-Object ProductName,CurrentBuild,CurrentBuildNumber,UBR,DisplayVersion,InstallationType }
    Capture-Json 'SchedulerPriorityPolicy' {
        $v = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' -Name Win32PrioritySeparation).Win32PrioritySeparation
        [pscustomobject]@{ Win32PrioritySeparationDecimal=$v; Win32PrioritySeparationHex=('0x{0:X2}' -f $v); Low6BitsBinary=[Convert]::ToString(($v -band 63),2).PadLeft(6,'0') }
    }
    Capture-Json 'DeviceGuard_VBS' { Get-CimInstance -Namespace 'root\Microsoft\Windows\DeviceGuard' -ClassName Win32_DeviceGuard | Select-Object VirtualizationBasedSecurityStatus, SecurityServicesConfigured, SecurityServicesRunning, AvailableSecurityProperties, RequiredSecurityProperties }
    Capture-Json 'MemoryIntegrity_Registry' { Get-ItemProperty -ErrorAction Stop 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' }
    Capture-Json 'NetworkAdapters' { Get-NetAdapter | Select-Object Name,InterfaceDescription,Status,DriverInformation,DriverVersion,LinkSpeed,MacAddress }
    Capture-Json 'NetworkRSS' { Get-NetAdapterRss }
    Capture-Json 'NetworkRSC' { Get-NetAdapterRsc }
    Capture-Json 'NetworkOffloads' { Get-NetAdapterAdvancedProperty | Select-Object Name,DisplayName,DisplayValue,RegistryKeyword,RegistryValue }
    Capture-Json 'VMware_PnP_Drivers' {
        Get-CimInstance Win32_PnPSignedDriver | Where-Object {
            $_.DeviceName -match 'VMware|PVSCSI|VMXNET|Virtual Ethernet|SCSI Controller' -or
            $_.DriverProviderName -match 'VMware|Broadcom'
        } | Select-Object DeviceName, DeviceID, DriverProviderName, DriverVersion, DriverDate, InfName
    }
    Capture-Json 'KernelAndDriverFileVersions' {
        $names = @('ntoskrnl.exe','storport.sys','ndis.sys','pvscsi.sys','vmxnet3.sys','vmci.sys')
        foreach ($nm in $names) {
            $item = @((Join-Path $env:SystemRoot ('System32\' + $nm)), (Join-Path $env:SystemRoot ('System32\drivers\' + $nm))) |
                ForEach-Object { Get-Item -LiteralPath $_ -ErrorAction SilentlyContinue } | Select-Object -First 1
            if ($null -ne $item) {
                [pscustomobject]@{ File=$nm; Path=$item.FullName; Version=$item.VersionInfo.FileVersion; LastWriteUTC=$item.LastWriteTimeUtc; SHA256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash }
            }
        }
    }
    Capture-Json 'SecurityServices' {
        Get-CimInstance Win32_Service | Where-Object {
            $_.Name -match 'Defend|Sense|VMTool|vgauth|carbon|crowd|sentinel|edr|falcon' -or
            $_.DisplayName -match 'Defend|VMware|endpoint|security|antivirus|carbon|crowd|sentinel'
        } | Select-Object Name,DisplayName,State,StartMode,PathName
    }
    Capture-Json 'Defender_Status' { Get-MpComputerStatus | Select-Object AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled,AntivirusSignatureVersion }
    Capture-Json 'Active_TCP_Settings' { netsh int tcp show global }
    Capture-Text 'Power_Scheme' { powercfg /getactivescheme }
    Capture-Text 'BCD_Current' { bcdedit /enum '{current}' }
    Capture-Text 'Filter_Drivers' { fltmc filters }
    Capture-Text 'WPR_Profiles' { wpr -profiles }
    Capture-Text 'System_Information' { systeminfo }
    Capture-Text 'How_To_Analyze' {
        @'
All processes (including zero-switch processes): Process_Samples_All.csv
All sampled threads: Thread_Samples_All.csv
Per-executable combined rates: Process_ByName_Averages.csv
All processes separately by PID: Process_ByPID_Averages.csv
Total system CPU and switches: System_Samples.csv, System_Averages.csv
Per-CPU interrupts/DPC: Processor_Samples_PerCPU.csv
ETW trace when requested: Scheduler_Trace.etl (open in Windows Performance Analyzer)

Context-switch/sec values are perf-counter rate estimates, not exact event totals.
A per-thread rate is attributed to that thread (not the thread causing it to run).
Process rates are summed across observed threads. They may differ from the
System ContextSwitchesPersec rate because of polling skew, exiting threads,
WMI formatted-counter sampling windows and measurement overhead.

For causal details: WPA CPU Usage (Precise): old/new thread, state, readying
thread/stack, wait reason, priorities, execution and ready time.
Do not treat a high switch rate alone as evidence of a regression.

Reports include image paths/device identifiers; inspect before sharing externally.
'@
    }
}

try {
    $windowsUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $isAdmin = (New-Object Security.Principal.WindowsPrincipal($windowsUser)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $isAdmin) { throw 'Run this PowerShell session AS ADMINISTRATOR to capture complete process and kernel evidence.' }
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    $logical = [int]$cs.NumberOfLogicalProcessors
    if ($logical -le 0) { $logical = 1 }
    $startUtc = (Get-Date).ToUniversalTime()
    $meta = [ordered]@{ Host=$env:COMPUTERNAME; Label=$Label; StartedUTC=$startUtc.ToString('o'); OS=$os.Caption; OSBuild=$os.BuildNumber; LogicalCPUs=$logical; RequestedSamples=$Samples; IntervalSeconds=$IntervalSeconds; ETWRequested=[bool]$TraceETW; CollectorVersion='1.0' }
    $meta | ConvertTo-Json | Out-File -LiteralPath (Join-Path $folder 'Run_Metadata.json') -Encoding UTF8

    Save-Inventories
    $initial = Read-Processes
    Export-Rows $initial (Join-Path $folder 'Processes_Start_Inventory.csv')
    $pidName = @{}
    foreach ($p in $initial) { $pidName[[string]$p.ProcessId] = $p.Name }

    # Fail fast if the essential source cannot be queried.
    $null = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfProc_Thread -ErrorAction Stop)
    $null = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfProc_Process -ErrorAction Stop)
    $null = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_System -ErrorAction Stop)
    Start-Sleep -Seconds 1 # Warm up formatted rate counters.

    $wprCmd = $null
    $etwStarted = $false
    if ($TraceETW) {
        $wprCmd = Get-Command wpr.exe -ErrorAction SilentlyContinue
        if (-not $wprCmd) { throw 'WPR.exe was not found. Omit -TraceETW or install the Windows Performance Recorder tooling.' }
        Write-Host 'Starting WPR GeneralProfile (memory mode)...'
        & $wprCmd.Source -start GeneralProfile
        if ($LASTEXITCODE -ne 0) { throw 'WPR could not start GeneralProfile. Check whether another WPR recording is already in progress.' }
        $etwStarted = $true
    }

    $successful = 0
    try {
        for ($i=1; $i -le $Samples; $i++) {
            $watch = [System.Diagnostics.Stopwatch]::StartNew()
            $nowUtc = (Get-Date).ToUniversalTime().ToString('o')
            $threads = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfProc_Thread)
            $processes = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfProc_Process)
            $system = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_System)
            $procsCPU = @(Get-CimInstance -ClassName Win32_PerfFormattedData_PerfOS_Processor)
            if ($threads.Count -eq 0 -or $processes.Count -eq 0 -or $system.Count -eq 0) {
                throw "Essential WMI performance classes returned no data in sample $i"
            }

            $threadRows = New-Object System.Collections.Generic.List[object]
            $threadAgg = @{}
            foreach ($t in $threads) {
                if ($t.Name -eq '_Total') { continue }
                $pidKey = [string]$t.IDProcess
                $rate = N $t.ContextSwitchesPerSec
                if (-not $threadAgg.ContainsKey($pidKey)) { $threadAgg[$pidKey] = @{ Rate=0.0; Threads=0; Peak=0.0 } }
                $threadAgg[$pidKey].Rate += $rate
                $threadAgg[$pidKey].Threads++
                if ($rate -gt $threadAgg[$pidKey].Peak) { $threadAgg[$pidKey].Peak = $rate }
                $threadRows.Add([pscustomobject]@{
                    Sample=$i; TimestampUTC=$nowUtc; PID=$t.IDProcess; TID=$t.IDThread;
                    PerfInstance=$t.Name; SwitchesPerSec=$rate;
                    PriorityBase=$t.PriorityBase; PriorityCurrent=$t.PriorityCurrent;
                    ThreadState=$t.ThreadState; ThreadWaitReason=$t.ThreadWaitReason;
                    CPUPercent_OneLogical=$t.PercentProcessorTime;
                    PrivilegedCPUPercent_OneLogical=$t.PercentPrivilegedTime
                })
            }
            Export-Rows $threadRows.ToArray() $threadCsv

            $processRows = New-Object System.Collections.Generic.List[object]
            $nameAgg = @{}
            $processPids = @{}
            foreach ($p in $processes) {
                if ($p.Name -eq '_Total') { continue }
                $pidKey = [string]$p.IDProcess
                $processPids[$pidKey] = $true
                $displayName = if ($pidName.ContainsKey($pidKey)) { $pidName[$pidKey] } else {
                    if ($p.Name -match '^(Idle|System|Registry)$') { $p.Name }
                    else { (($p.Name -replace '#\d+$','') + '.exe') }
                }
                $rate = if ($threadAgg.ContainsKey($pidKey)) { $threadAgg[$pidKey].Rate } else { 0.0 }
                $threadCount = if ($threadAgg.ContainsKey($pidKey)) { $threadAgg[$pidKey].Threads } else { 0 }
                $cpuPct = (N $p.PercentProcessorTime) / $logical
                $processRows.Add([pscustomobject]@{
                    Sample=$i; TimestampUTC=$nowUtc; PID=$p.IDProcess; ProcessName=$displayName;
                    SwitchesPerSec=$rate; MeasuredThreads=$threadCount;
                    ThreadCountReported=$p.ThreadCount;
                    CPUPercent_OfVM=[math]::Round($cpuPct,3);
                    PrivilegedCPUPercent_OfVM=[math]::Round(((N $p.PercentPrivilegedTime) / $logical),3);
                    HandleCount=$p.HandleCount
                })
                if (-not $nameAgg.ContainsKey($displayName)) {
                    $nameAgg[$displayName] = @{ Rate=0.0; CPU=0.0; Count=0 }
                }
                $nameAgg[$displayName].Rate += $rate
                $nameAgg[$displayName].CPU += $cpuPct
                $nameAgg[$displayName].Count++
            }
            # Retain thread-only PIDs if process has exited between separate WMI reads.
            foreach ($pidKey in $threadAgg.Keys) {
                if ($processPids.ContainsKey($pidKey)) { continue }
                $displayName = if ($pidName.ContainsKey($pidKey)) { $pidName[$pidKey] } else { '<exited or unmapped>' }
                $rate = $threadAgg[$pidKey].Rate
                $processRows.Add([pscustomobject]@{
                    Sample=$i; TimestampUTC=$nowUtc; PID=[int]$pidKey; ProcessName=$displayName;
                    SwitchesPerSec=$rate; MeasuredThreads=$threadAgg[$pidKey].Threads;
                    ThreadCountReported=$null; CPUPercent_OfVM=$null;
                    PrivilegedCPUPercent_OfVM=$null; HandleCount=$null
                })
                if (-not $nameAgg.ContainsKey($displayName)) { $nameAgg[$displayName] = @{ Rate=0.0;CPU=0.0;Count=0 } }
                $nameAgg[$displayName].Rate += $rate
                $nameAgg[$displayName].Count++
            }
            Export-Rows $processRows.ToArray() $procCsv

            $nameRows = New-Object System.Collections.Generic.List[object]
            foreach ($name in $nameAgg.Keys) {
                $nameRows.Add([pscustomobject]@{
                    Sample=$i; TimestampUTC=$nowUtc; ProcessName=$name;
                    SwitchesPerSec=$nameAgg[$name].Rate;
                    CPUPercent_OfVM=[math]::Round($nameAgg[$name].CPU,3);
                    ProcessCount=$nameAgg[$name].Count
                })
            }
            Export-Rows $nameRows.ToArray() $nameCsv

            $s = $system[0]
            $sum = 0.0
            foreach ($entry in $threadAgg.Values) { $sum += [double]$entry.Rate }
            Export-Rows @([pscustomobject]@{
                Sample=$i; TimestampUTC=$nowUtc;
                SystemSwitchesPerSec=$s.ContextSwitchesPersec;
                SumThreadSwitchesPerSec=$sum;
                ReconciliationGapPerSec=([double]$s.ContextSwitchesPersec-$sum);
                ProcessorQueueLength=$s.ProcessorQueueLength;
                SystemCallsPerSec=$s.SystemCallsPersec;
                ThreadInstances=$threadRows.Count;
                ProcessInstances=$processRows.Count
            }) $sysCsv

            $cpuRows = @($procsCPU | ForEach-Object {
                [pscustomobject]@{
                    Sample=$i; TimestampUTC=$nowUtc; CPUInstance=$_.Name;
                    CPUPercent=$_.PercentProcessorTime;
                    PrivilegedPercent=$_.PercentPrivilegedTime;
                    DPCPercent=$_.PercentDPCTime;
                    InterruptPercent=$_.PercentInterruptTime;
                    InterruptsPerSec=$_.InterruptsPersec;
                    DPCsQueuedPerSec=$_.DPCsQueuedPersec
                }
            })
            Export-Rows $cpuRows $cpuCsv

            $successful++
            $watch.Stop()
            Write-Host ('Sample {0}/{1}: System {2:N0} switches/sec; {3} thread rows; collection {4:N2}s' -f $i,$Samples,$s.ContextSwitchesPersec,$threadRows.Count,$watch.Elapsed.TotalSeconds)
            if ($i -lt $Samples) {
                # This is a target polling delay, not a guarantee of a fixed sampling period.
                Start-Sleep -Seconds $IntervalSeconds
            }
        }
    } finally {
        if ($etwStarted) {
            Write-Host 'Stopping WPR and saving ETW trace...'
            & $wprCmd.Source -stop $etwFile 'Server scheduler comparison under load'
            if ($LASTEXITCODE -ne 0) { Warn-Collector 'WPR' 'WPR stop failed; ETL may be incomplete.' }
        }
    }

    # Snapshot any processes started during collection, to improve PID/name matching.
    $ending = Read-Processes
    Export-Rows $ending (Join-Path $folder 'Processes_End_Inventory.csv')

    $procData = @(Import-Csv -LiteralPath $procCsv)
    $byPid = foreach ($g in ($procData | Group-Object PID)) {
        $rows = @($g.Group)
        $first = $rows[0]
        $rates = @($rows | ForEach-Object { [double]$_.SwitchesPerSec })
        $cpus  = @($rows | ForEach-Object { if ($_.CPUPercent_OfVM -ne '') { [double]$_.CPUPercent_OfVM } })
        [pscustomobject]@{
            PID=[int]$first.PID; ProcessName=$first.ProcessName;
            SamplesSeen=$rows.Count;
            AvgSwitchesPerSec=[math]::Round((($rates | Measure-Object -Average).Average),3);
            MaxSwitchesPerSec=[math]::Round((($rates | Measure-Object -Maximum).Maximum),3);
            AvgCPUPercent_OfVM=$(if ($cpus.Count) { [math]::Round((($cpus | Measure-Object -Average).Average),3) } else { $null });
            AvgMeasuredThreads=[math]::Round((($rows | Measure-Object -Property MeasuredThreads -Average).Average),2)
        }
    }
    $byPid | Sort-Object -Property AvgSwitchesPerSec -Descending |
        Export-Csv (Join-Path $folder 'Process_ByPID_Averages.csv') -NoTypeInformation -Encoding UTF8

    # Every process name observed during at least one sample; missing time slots
    # count as zero so short-lived workloads can be compared fairly.
    $nameData = @(Import-Csv -LiteralPath $nameCsv)
    $byName = foreach ($g in ($nameData | Group-Object ProcessName)) {
        $rates = @($g.Group | ForEach-Object { [double]$_.SwitchesPerSec })
        $cpus = @($g.Group | ForEach-Object { [double]$_.CPUPercent_OfVM })
        [pscustomobject]@{
            ProcessName=$g.Name;
            SamplesSeen=$g.Count;
            AvgSwitchesPerSec=[math]::Round((($rates | Measure-Object -Sum).Sum/$successful),3);
            MaxSwitchesPerSec=[math]::Round((($rates | Measure-Object -Maximum).Maximum),3);
            AvgCPUPercent_OfVM=[math]::Round((($cpus | Measure-Object -Sum).Sum/$successful),3)
        }
    }
    $byName | Sort-Object -Property AvgSwitchesPerSec -Descending |
        Export-Csv (Join-Path $folder 'Process_ByName_Averages.csv') -NoTypeInformation -Encoding UTF8

    $sysData = @(Import-Csv -LiteralPath $sysCsv)
    $sysSummary = @(
        foreach ($field in @('SystemSwitchesPerSec','SumThreadSwitchesPerSec','ReconciliationGapPerSec','ProcessorQueueLength','SystemCallsPerSec','ThreadInstances','ProcessInstances')) {
            $nums = @($sysData | ForEach-Object { [double]($_.$field) })
            [pscustomobject]@{
                Metric=$field;
                Mean=[math]::Round((($nums | Measure-Object -Average).Average),3);
                Min=[math]::Round((($nums | Measure-Object -Minimum).Minimum),3);
                Max=[math]::Round((($nums | Measure-Object -Maximum).Maximum),3)
            }
        }
    )
    $sysSummary | Export-Csv (Join-Path $folder 'System_Averages.csv') -NoTypeInformation -Encoding UTF8

    $cpuData = @(Import-Csv -LiteralPath $cpuCsv | Where-Object { $_.CPUInstance -eq '_Total' })
    if ($cpuData.Count) {
        @('CPUPercent','PrivilegedPercent','DPCPercent','InterruptPercent','InterruptsPerSec','DPCsQueuedPerSec') | ForEach-Object {
            $field = $_
            $values = @($cpuData | ForEach-Object { if ($_.$field -ne '') { [double]($_.$field) } })
            if ($values.Count) {
                [pscustomobject]@{Metric=$field; Mean=[math]::Round((($values | Measure-Object -Average).Average),3)}
            }
        } | Export-Csv (Join-Path $folder 'CPU_Averages.csv') -NoTypeInformation -Encoding UTF8
    }
    $meta['SuccessfulSamples'] = $successful
    $meta['FinishedUTC'] = (Get-Date).ToUniversalTime().ToString('o')
    $meta | ConvertTo-Json | Out-File -LiteralPath (Join-Path $folder 'Run_Metadata.json') -Encoding UTF8
    Write-Host "Finished: $folder" -ForegroundColor Green
    Write-Host 'Every process: Process_ByPID_Averages.csv; grouped by executable: Process_ByName_Averages.csv'
    Write-Host 'Every thread sample: Thread_Samples_All.csv'

    if (-not $NoZip) {
        $zipFile = "$folder.zip"
        # Keep large ETL separate so ordinary summary ZIPs stay transportable.
        $toZip = @(Get-ChildItem -LiteralPath $folder -File | Where-Object { $_.Extension -ne '.etl' })
        Compress-Archive -LiteralPath $toZip.FullName -DestinationPath $zipFile -CompressionLevel Optimal -Force
        Write-Host "Summary ZIP: $zipFile" -ForegroundColor Green
        if ($TraceETW) { Write-Host "ETW trace (separate): $etwFile" }
    }
} catch {
    Warn-Collector 'Fatal' $_.Exception.ToString()
    throw
}
