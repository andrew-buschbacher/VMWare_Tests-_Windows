# Windows Server 2022 vs. 2025 — Mac-controlled VMware scheduler comparison

This toolkit coordinates **two sequential** tests from a MacBook:

1. SSH to the first Windows VM; stage `Collect-WindowsSchedulerEvidence.ps1` with SFTP.
2. Run the PowerShell collector on that VM; capture **all processes and all sampled threads**, CPU/DPC/interrupt, scheduler/security/driver inventory, and optionally WPR ETW.
3. Download the Windows summary ZIP to the Mac; optionally download the ETL.
4. Query **vCenter** for 20-second CPU Ready/Co-Stop/Run/Wait samples over the **Windows collector's actual UTC sample window**, including each vCPU when exposed.
5. Repeat steps 1–4 **on the second VM** (never run both Windows collectors at the same time).
6. Generate combined all-process, per-thread, Windows-system and vCenter CPU scheduling comparisons; ZIP up the evidence (ETLs excluded).

This does **not** start the workload/benchmark. Start the *same* workload at the same, steady load on each VM before its collection begins. A sequential test avoids simultaneous Windows collections but does not by itself ensure equal workloads or uncontended ESXi resources.

## Mac setup

Python 3.9+ with macOS Terminal and vCenter/network access.

```bash
unzip windows-vmware-orchestrator.zip
cd windows-vmware-orchestrator
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
```

Optional: verify SSH host identities before automation, **on each VM**:

```bash
ssh 'administrator@win2022.example.org' whoami
ssh 'administrator@win2025.example.org' whoami
```

Compare each SSH host key fingerprint through a trusted administrative channel before accepting it. `paramiko` enforces `~/.ssh/known_hosts`, rather than automatically trusting new hosts. Domain accounts can use `DOMAIN\\user@hostname` as the SSH target, quoted appropriately.

**SSH/SFTP requirements on Windows:** OpenSSH Server running, TCP 22 reachable, SFTP subsystem enabled, and an authorized Windows administrator SSH login with an elevated/administrative token. The collection script checks elevation and stops if it is unavailable. SSH itself cannot silently elevate a restricted session. The script invokes `powershell.exe` directly and does **not** require changing OpenSSH's default shell from `cmd.exe`.

If OpenSSH Server is not enabled, an authorized Windows administrator may check/configure it in an elevated PowerShell prompt:

```powershell
Get-WindowsCapability -Online -Name OpenSSH.Server*
# Only if not installed:
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
Start-Service sshd
Set-Service sshd -StartupType Automatic
```

Ensure firewall policy, SSH public keys/password settings, and SFTP permissions meet your organization's security standards. This toolkit does not change those settings.

## Run both VMs from Mac

```bash
python3 run_scheduler_comparison.py \
  --vcenter vcsa.example.org \
  --vcenter-user 'readonly@vsphere.local' \
  --target '2022|admin@win2022.example.org|EXACT VM NAME 2022' \
  --target '2025|admin@win2025.example.org|EXACT VM NAME 2025' \
  --samples 30 \
  --interval-seconds 2 \
  --output ./evidence
```

The program prompts for your vCenter password; SSH uses your agent/default keys. If SSH password authentication is enabled and required, add `--ssh-password` (prompts for each host separately). If using a nonstandard key: `--ssh-key ~/.ssh/id_ed25519`.

When vCenter uses a private CA, supply `--vcenter-ca-file /path/to/company-ca.pem`. TLS verification is ON by default. **Avoid** `--insecure-vcenter` except in a disposable laboratory.

Each Windows collector executes sequentially, and the Python program queries vCenter after each Windows capture. The vCenter API serves retained 20-second samples for the same period, so there's no separate continuously running VMware collector. Real-time history is normally retained for ~1 hour; use modest Windows captures so the first samples are still available.

### With optional Windows ETW tracing

```bash
python3 run_scheduler_comparison.py \
  --vcenter vcsa.example.org --vcenter-user 'readonly@vsphere.local' \
  --target '2022|admin@win2022.example.org|EXACT VM NAME 2022' \
  --target '2025|admin@win2025.example.org|EXACT VM NAME 2025' \
  --trace-etw --download-etl \
  --samples 30 --interval-seconds 2
```

`--trace-etw` uses WPR `GeneralProfile` (the Windows machine must have WPR available). ETLs can be **very large**; `--download-etl` is separate so summary ZIPs stay compact. Without `--download-etl`, the trace remains on Windows under the remote working directory. ETW can alter system timing; compare with non-ETW baselines too.

## Outputs

```text
evidence/
  orchestrator_manifest.json
  vcenter-preflight.log
  runs/
    2022/
      run_manifest.json
      windows-collector.log
      windows_summary.zip
      windows/
        Process_ByPID_Averages.csv        # ALL PIDs, including zero-switch processes
        Process_ByName_Averages.csv       # ALL executable names combined
        Thread_Samples_All.csv           # ALL sampled threads, PID/TID, priorities/waits
        System_Samples.csv
        CPU_Averages.csv
        System_Averages.csv
        ... many configuration and driver inventory files ...
      thread_switch_summary.csv           # every observed PID/TID, sorted by switches/sec
      vcenter/
        raw_metrics.csv                   # per-vCPU and aggregate raw values
        vm_samples.csv                    # per-sample normalized values
        summary_by_vm.csv                 # average/p95/max per-vCPU metrics
        summary_by_vcpu.csv               # when vCenter exposes per-vCPU instances
        inventory.json
        collection_metadata.json
    2025/
      ... same organization ...
  comparison/
    all_process_context_switch_deltas.csv  # every process executable, not top-N only
    windows_system_deltas.csv
    vcenter_cpu_scheduling_deltas.csv

evidence_shareable_results.zip             # next to evidence/, ETLs excluded
```

The script collects vCenter VM identification and ESXi host/build/configuration, CPU Ready, Co-Stop, Run, Wait, limits and other available CPU timing metrics. Some counters may be unavailable depending on vSphere version, VM state, and statistics level. They remain marked missing and are not fabricated as zero.

### Interpretation

- **Windows `Context Switches/sec`** counts Windows *thread* scheduling; vCenter `%RDY` and `%CSTP` are ESXi *vCPU* scheduling data. These are different phenomena.
- Windows process rates are sums of sampled WMI formatted **thread** counters. They are estimates, and may not exactly reconcile with the independently polled System counter. Use `System_Samples.csv` for the reconciliation gap.
- `Thread_Samples_All.csv` attributes a switch rate to the thread switched *in or out*, but it does not on its own reveal the thread or interrupt that caused the scheduling decision. For causal attribution use WPA ETW `CPU Usage (Precise)` and ready-thread stacks.
- `Thread_Samples_All.csv` records sampled thread **state and wait reason**, not a complete history. They should not be treated as reasons for every context switch.
- Both tests occur **one after another**, not simultaneously. Compare representative steady-state workload intervals, physical host availability, and guest/ESXi clocks.
- A per-vCPU VMware ready percentage is `ready_ms / (sample_seconds * 1000) * 100`; VM aggregate ready percentage can exceed 100%, so summary reports **mean per vCPU** separately.
- Do **not** use `--insecure-vcenter` on production vCenter unless security policy explicitly allows it.

### Cleanup and sensitive data

The Windows collector is diagnostic/read-only with respect to OS settings, but this orchestrator creates temporary collection files under `C:\SchedulerEvidence\MacControl_*`. Remove them manually **after verifying downloads** if desired. It does not modify production scheduler, security or VMware settings.

Outputs can contain internal VM names, hostnames, process executable paths, system configuration, IP-related values, device IDs and the ETL's detailed execution traces. Review them before sharing outside your organization. The ZIP excludes ETL files but includes the inventory data.

## Validation

Python code passes syntax validation and offline fixture checks; **not tested live against your Windows VMs or vCenter**. `SFTP` Windows path syntax assumes the Microsoft native OpenSSH server (`/C:/...` drive syntax); custom SFTP servers may require adjustment.
