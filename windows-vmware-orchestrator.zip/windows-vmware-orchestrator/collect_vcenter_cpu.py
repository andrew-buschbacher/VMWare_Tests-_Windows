#!/usr/bin/env python3
"""Read-only VMware vCenter CPU scheduling evidence collector via pyVmomi.

Designed for pairing ESXi-side vCPU timing with Windows ETW / PerfMon evidence.
Outputs UTC-timestamped raw and normalized metric data for EVERY vCPU exposed
by vCenter, where collection level makes those instances available.
"""

import argparse
import csv
import getpass
import json
import os
from pathlib import Path
import re
import ssl
import statistics
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone

try:
    from pyVim.connect import SmartConnect, Disconnect
    from pyVmomi import vim, vmodl
except ImportError:
    sys.exit("pyVmomi is missing. Install it with: python3 -m pip install pyvmomi")

METRICS = (
    "cpu.ready.summation",       # %RDY equivalent (milliseconds)
    "cpu.costop.summation",      # %CSTP equivalent (milliseconds)
    "cpu.run.summation",         # %RUN equivalent (milliseconds)
    "cpu.wait.summation",        # %WAIT equivalent (milliseconds)
    "cpu.maxlimited.summation",  # %MLMTD equivalent (milliseconds)
    "cpu.used.summation",
    "cpu.overlap.summation",
    "cpu.idle.summation",
    "cpu.system.summation",
    "cpu.usage.average",        # guest VM capacity use (percent, may be scaled)
    "cpu.usagemhz.average",
    "cpu.latency.average",      # % CPU scheduling latency, if available
    "cpu.readiness.average",    # % ready, if available
)
TIME_METRICS = tuple(m for m in METRICS if m.endswith(".summation"))
SUMMARY_TIME_METRICS = (
    "cpu.ready.summation", "cpu.costop.summation", "cpu.run.summation",
    "cpu.wait.summation", "cpu.maxlimited.summation",
)


def utc_iso(dt):
    if dt is None:
        return ""
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_utc(s):
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"Bad ISO timestamp {s!r}: {exc}")
    if dt.tzinfo is None:
        raise argparse.ArgumentTypeError("Specify UTC or an explicit offset, e.g. 2026-11-01T17:00:00Z")
    return dt.astimezone(timezone.utc)


def safe_get(obj, *path):
    try:
        for part in path:
            obj = getattr(obj, part)
        return obj
    except (AttributeError, TypeError, vmodl.fault.ManagedObjectNotFound):
        return None


def simple(value):
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, datetime):
        return utc_iso(value)
    if isinstance(value, (list, tuple)):
        return [simple(x) for x in value]
    if hasattr(value, "_moId"):
        return value._moId
    return str(value)


def csv_write(path, rows, columns):
    with path.open("w", encoding="utf-8", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def json_write(path, obj):
    with path.open("w", encoding="utf-8") as fp:
        json.dump(obj, fp, indent=2, sort_keys=True, default=simple)
        fp.write("\n")


def slug(text):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("._-") or "collection"


def vm_inventory(content):
    view = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    )
    try:
        return list(view.view)
    finally:
        view.Destroy()


def describe_vm(vm, vcenter):
    host = safe_get(vm, "runtime", "host")
    cpu_cfg = safe_get(vm, "config", "hardware")
    allocation = safe_get(vm, "resourceConfig", "cpuAllocation")
    env = safe_get(vm, "config", "cpuAffinity", "affinitySet")
    return {
        "vcenter": vcenter,
        "vm": vm.name,
        "moid": vm._moId,
        "instance_uuid": simple(safe_get(vm, "config", "instanceUuid")),
        "bios_uuid": simple(safe_get(vm, "config", "uuid")),
        "guest_os_id": simple(safe_get(vm, "config", "guestId")),
        "guest_full_name": simple(safe_get(vm, "config", "guestFullName")),
        "guest_reported_os": simple(safe_get(vm, "guest", "guestFullName")),
        "powered_state": simple(safe_get(vm, "runtime", "powerState")),
        "vcpus": simple(safe_get(cpu_cfg, "numCPU")),
        "cores_per_socket": simple(safe_get(cpu_cfg, "numCoresPerSocket")),
        "virtual_hardware": simple(safe_get(vm, "config", "version")),
        "cpu_hot_add": simple(safe_get(vm, "config", "cpuHotAddEnabled")),
        "cpu_limit_mhz": simple(safe_get(allocation, "limit")),
        "cpu_reservation_mhz": simple(safe_get(allocation, "reservation")),
        "cpu_shares": simple(safe_get(allocation, "shares", "shares")),
        "cpu_shares_level": simple(safe_get(allocation, "shares", "level")),
        "cpu_affinity": simple(env),
        "latency_sensitivity": simple(safe_get(vm, "config", "latencySensitivity", "level")),
        "vmware_tools_version": simple(safe_get(vm, "config", "tools", "toolsVersion")),
        "vmware_tools_status": simple(safe_get(vm, "guest", "toolsRunningStatus")),
        "host_name": simple(safe_get(host, "name")),
        "host_moid": simple(getattr(host, "_moId", None)),
        "host_cpu_model": simple(safe_get(host, "summary", "hardware", "cpuModel")),
        "host_cpu_cores": simple(safe_get(host, "hardware", "cpuInfo", "numCpuCores")),
        "host_logical_cpus": simple(safe_get(host, "hardware", "cpuInfo", "numCpuThreads")),
        "host_esxi_version": simple(safe_get(host, "config", "product", "version")),
        "host_esxi_build": simple(safe_get(host, "config", "product", "build")),
        "vm_uptime_seconds": simple(safe_get(vm, "summary", "quickStats", "uptimeSeconds")),
    }


def make_counter_maps(perf):
    byname = {}
    byid = {}
    for ci in perf.perfCounter:
        key = ".".join((str(ci.groupInfo.key), str(ci.nameInfo.key), str(ci.rollupType)))
        byname[key] = ci.key
        byid[ci.key] = {
            "counter": key,
            "unit": str(ci.unitInfo.key),
            "scale": int(getattr(ci, "scale", 0) or 0),
            "level": int(getattr(ci, "level", 0) or 0),
        }
    return byname, byid


def query_vm(perf, vm, counter_names, byname, start, end, interval):
    available = perf.QueryAvailablePerfMetric(entity=vm, intervalId=interval) or []
    avail_ids = {m.counterId for m in available}
    selected = [name for name in counter_names if name in byname and byname[name] in avail_ids]
    missing = {name: ("not advertised by vCenter" if name not in byname else "not available at this interval/statistics level")
               for name in counter_names if name not in selected}
    if not selected:
        return [], missing, []
    # Asterisk returns all available instances, including vCPU-level instances
    # when those have been collected at this statistics level.
    metric_ids = [vim.PerformanceManager.MetricId(counterId=byname[name], instance="*") for name in selected]
    spec = vim.PerformanceManager.QuerySpec(
        entity=vm, startTime=start, endTime=end,
        intervalId=interval, metricId=metric_ids,
    )
    results = perf.QueryPerf(querySpec=[spec]) or []
    rows = []
    sample_times = []
    for result in results:
        infos = getattr(result, "sampleInfo", []) or []
        for si in infos:
            sample_times.append(utc_iso(si.timestamp))
        for series in (getattr(result, "value", []) or []):
            counter_id = series.id.counterId
            instance = str(series.id.instance or "")
            values = series.value or []
            counter_info = byid[counter_id]
            for si, raw in zip(infos, values):
                # vCenter returns -1 for missing/invalid values in some counters.
                if raw is None or raw == -1:
                    continue
                scaled = float(raw) * (10 ** counter_info["scale"])
                interval_s = int(si.interval)
                name = counter_info["counter"]
                pct_slot = None
                if name in TIME_METRICS and counter_info["unit"] == "millisecond" and interval_s > 0:
                    pct_slot = scaled * 100.0 / (interval_s * 1000.0)
                rows.append({
                    "vm": vm.name, "moid": vm._moId,
                    "timestamp_utc": utc_iso(si.timestamp),
                    "interval_seconds": interval_s,
                    "metric": name, "instance": instance,
                    "raw_value": raw, "scale": counter_info["scale"],
                    "scaled_value": scaled, "unit": counter_info["unit"],
                    "percent_of_one_vcpu_slot": pct_slot,
                })
    return rows, missing, sorted(set(sample_times))


def normalize_vm_rows(raw, inventory):
    grouped = defaultdict(lambda: {"aggregate": None, "vcpus": {}})
    for r in raw:
        key = (r["vm"], r["timestamp_utc"], r["interval_seconds"], r["metric"])
        if r["instance"] == "":
            grouped[key]["aggregate"] = r
        else:
            grouped[key]["vcpus"][r["instance"]] = r
    by_vm = {r["vm"]: r for r in inventory}
    out = []
    for (vm, ts, seconds, metric), values in sorted(grouped.items()):
        agg = values["aggregate"]
        vcpu_vals = values["vcpus"]
        n = int(by_vm[vm]["vcpus"] or 1)
        covered = len(vcpu_vals)
        full = covered == n
        sample_unit = (agg or next(iter(vcpu_vals.values())))["unit"]
        agg_val = agg["scaled_value"] if agg else None
        # Only infer totals from per-vCPU data if ALL vCPU instances are present.
        from_source = "vcenter_aggregate" if agg else ("sum_all_vcpus" if full else "incomplete_vcpu_coverage")
        if agg_val is None and full and metric in TIME_METRICS:
            agg_val = sum(x["scaled_value"] for x in vcpu_vals.values())
        if metric in TIME_METRICS and sample_unit == "millisecond":
            pct_sum = agg_val * 100.0 / (seconds * 1000.0) if agg_val is not None else None
            pct_avg = pct_sum / n if pct_sum is not None else None
            # Sanity check: aggregate sum can exceed 100% for multicore VMs.
            mean_sampled = statistics.mean(x["percent_of_one_vcpu_slot"] for x in vcpu_vals.values()) if vcpu_vals else None
            out.append({
                "vm": vm, "timestamp_utc": ts, "interval_seconds": seconds,
                "metric": metric, "value": agg_val, "unit": sample_unit,
                "sum_vcpu_percent": pct_sum, "mean_per_vcpu_percent": pct_avg,
                "sampled_vcpu_mean_percent": mean_sampled,
                "sampled_vcpus": covered, "configured_vcpus": n,
                "source": from_source,
            })
        else:
            # Usage/MHz/latency metrics retain their native scaled units.
            out.append({
                "vm": vm, "timestamp_utc": ts, "interval_seconds": seconds,
                "metric": metric, "value": agg_val, "unit": sample_unit,
                "sum_vcpu_percent": None, "mean_per_vcpu_percent": None,
                "sampled_vcpu_mean_percent": None,
                "sampled_vcpus": covered, "configured_vcpus": n,
                "source": from_source,
            })
    return out


def p95(numbers):
    nums = sorted(numbers)
    if not nums:
        return None
    index = 0.95 * (len(nums) - 1)
    lo = int(index)
    hi = min(lo + 1, len(nums) - 1)
    return nums[lo] + (nums[hi] - nums[lo]) * (index - lo)


def summaries(normalized, raw, inventory):
    by_vm_metric = defaultdict(list)
    for r in normalized:
        if r["mean_per_vcpu_percent"] is not None:
            by_vm_metric[(r["vm"], r["metric"])].append(r["mean_per_vcpu_percent"])
    vm_sum = []
    for inv in inventory:
        vm = inv["vm"]
        for metric in SUMMARY_TIME_METRICS:
            nums = by_vm_metric.get((vm, metric), [])
            vm_sum.append({
                "vm": vm, "metric": metric, "samples": len(nums),
                "average_per_vcpu_percent": round(statistics.mean(nums), 4) if nums else None,
                "p95_per_vcpu_percent": round(p95(nums), 4) if nums else None,
                "maximum_per_vcpu_percent": round(max(nums), 4) if nums else None,
            })
    by_cpu = defaultdict(list)
    for r in raw:
        if r["instance"] and r["percent_of_one_vcpu_slot"] is not None:
            by_cpu[(r["vm"], r["instance"], r["metric"])].append(r["percent_of_one_vcpu_slot"])
    cpu_sum = []
    for (vm, instance, metric), nums in sorted(by_cpu.items()):
        cpu_sum.append({
            "vm": vm, "vcpu_instance": instance, "metric": metric, "samples": len(nums),
            "average_percent": round(statistics.mean(nums), 4),
            "p95_percent": round(p95(nums), 4),
            "maximum_percent": round(max(nums), 4),
        })
    return vm_sum, cpu_sum


def parse_args():
    p = argparse.ArgumentParser(
        description="Read-only vCenter vCPU Ready/Co-Stop/Run/Wait capture; outputs timestamped CSV/JSON."
    )
    p.add_argument("--vcenter", required=True, help="vCenter FQDN/IP")
    p.add_argument("--user", required=True, help="vCenter login (e.g. user@vsphere.local)")
    p.add_argument("--vm", action="append", required=True, help="Exact VM inventory name; repeat --vm for more")
    p.add_argument("--password-env", default=None, metavar="ENV", help="Optional environment variable containing password")
    p.add_argument("--ca-file", help="PEM certificate authority bundle if vCenter has a private CA")
    p.add_argument("--insecure", action="store_true", help="Explicitly disable TLS certificate validation (lab use only)")
    p.add_argument("--minutes", type=int, default=30, help="Last N minutes if --start/--end omitted (default: 30)")
    p.add_argument("--interval", type=int, choices=(20, 300, 1800, 7200, 86400), default=20,
                   help="vCenter statistics interval in seconds (default: realtime 20)")
    p.add_argument("--start", type=parse_utc, help="Explicit start time with UTC or offset ISO8601")
    p.add_argument("--end", type=parse_utc, help="Explicit end time with UTC or offset ISO8601")
    p.add_argument("--output", help="Output directory (default: timestamped directory in current folder)")
    p.add_argument("--list-vms", action="store_true", help="List matching VM names and IDs before collecting")
    args = p.parse_args()
    if args.minutes < 1 or args.minutes > 43200:
        p.error("--minutes must be 1 through 43200")
    if bool(args.start) != bool(args.end):
        p.error("Supply both --start and --end, or neither")
    if args.start and args.start >= args.end:
        p.error("--start must precede --end")
    if args.insecure and args.ca_file:
        p.error("Use either --ca-file or --insecure, not both")
    return args


def main():
    args = parse_args()
    now = datetime.now(timezone.utc)
    start = args.start or (now - timedelta(minutes=args.minutes))
    end = args.end or now
    if args.interval == 20 and (now - start).total_seconds() > 3600:
        print("WARNING: vCenter usually retains real-time (20-second) samples for about one hour. ",
              "Older samples may be missing. Use --interval 300 for historical data.", file=sys.stderr)
    if args.interval != 20:
        print("WARNING: Historical statistics may not contain per-vCPU counters; ",
              "only reported instances will be exported.", file=sys.stderr)

    output = Path(args.output or f"vcenter-cpu-{now.strftime('%Y%m%dT%H%M%SZ')}").expanduser()
    output.mkdir(parents=True, exist_ok=True)
    password = os.environ.get(args.password_env) if args.password_env else None
    if password is None:
        password = getpass.getpass(f"Password for {args.user}@{args.vcenter}: ")
    context = ssl._create_unverified_context() if args.insecure else ssl.create_default_context(cafile=args.ca_file)
    si = None
    try:
        print(f"Connecting to {args.vcenter} ...")
        si = SmartConnect(host=args.vcenter, user=args.user, pwd=password,
                          sslContext=context, port=443)
        password = None
        content = si.RetrieveContent()
        perf = content.perfManager
        all_vms = vm_inventory(content)
        selected = []
        for name in args.vm:
            matching = [v for v in all_vms if v.name == name]
            if len(matching) != 1:
                ids = ", ".join(v._moId for v in matching)
                raise RuntimeError(f"Expected one VM named {name!r}, found {len(matching)} (IDs: {ids}). "
                                   "Rename/disambiguate duplicate inventory entries before using this tool.")
            selected.append(matching[0])
        if args.list_vms:
            for vm in selected:
                print(f"{vm.name}: moid={vm._moId} host={simple(safe_get(vm, 'runtime', 'host', 'name'))}")
            return 0
        byname, byid = make_counter_maps(perf)
        inventory = []
        raw = []
        missing = {}
        sampling = {}
        for vm in selected:
            meta = describe_vm(vm, args.vcenter)
            inventory.append(meta)
            print(f"Querying {vm.name} ({vm._moId}) | vCPUs={meta['vcpus']} | host={meta['host_name']} ...")
            data, not_found, times = query_vm(perf, vm, METRICS, byname, start, end, args.interval)
            raw.extend(data)
            missing[vm.name] = not_found
            sampling[vm.name] = {"returned_sample_timestamps": len(times),
                                  "first_sample_utc": times[0] if times else None,
                                  "last_sample_utc": times[-1] if times else None,
                                  "metric_rows": len(data)}
            print(f"  {len(data)} metric rows over {len(times)} sample timestamps; "
                  f"unavailable counters: {len(not_found)}")

        normalized = normalize_vm_rows(raw, inventory) if raw else []
        vm_summary, vcpu_summary = summaries(normalized, raw, inventory)
        csv_write(output / "raw_metrics.csv", raw, [
            "vm", "moid", "timestamp_utc", "interval_seconds", "metric", "instance",
            "raw_value", "scale", "scaled_value", "unit", "percent_of_one_vcpu_slot",
        ])
        csv_write(output / "vm_samples.csv", normalized, [
            "vm", "timestamp_utc", "interval_seconds", "metric", "value", "unit",
            "sum_vcpu_percent", "mean_per_vcpu_percent", "sampled_vcpu_mean_percent",
            "sampled_vcpus", "configured_vcpus", "source",
        ])
        csv_write(output / "summary_by_vm.csv", vm_summary, [
            "vm", "metric", "samples", "average_per_vcpu_percent",
            "p95_per_vcpu_percent", "maximum_per_vcpu_percent",
        ])
        csv_write(output / "summary_by_vcpu.csv", vcpu_summary, [
            "vm", "vcpu_instance", "metric", "samples", "average_percent",
            "p95_percent", "maximum_percent",
        ])
        json_write(output / "inventory.json", inventory)
        json_write(output / "collection_metadata.json", {
            "collected_at_utc": utc_iso(now), "request_start_utc": utc_iso(start),
            "request_end_utc": utc_iso(end), "interval_seconds": args.interval,
            "vcenter": args.vcenter, "samples": sampling, "missing_counters": missing,
            "measurement_notes": [
                "Raw cpu.ready/costop/run/etc summation counters are millisecond totals per interval.",
                "sum_vcpu_percent = aggregate_ms / (interval_seconds * 1000) * 100, potentially over 100%. ",
                "mean_per_vcpu_percent = sum_vcpu_percent / configured_vcpus.",
                "Per-vCPU instance percentages are individually normalized, not divided by vCPU count.",
                "No guest Windows thread context-switch counts are available from these ESXi scheduling metrics.",
                "Missing historical per-vCPU instances are not synthesized.",
            ],
        })
        print("\n=== VM-level scheduling evidence ===")
        for s in vm_summary:
            if s["metric"] in ("cpu.ready.summation", "cpu.costop.summation", "cpu.run.summation"):
                print(f"{s['vm']:<30} {s['metric']:<24} "
                      f"mean/vCPU={str(s['average_per_vcpu_percent'])+'%' if s['samples'] else 'N/A':<10} "
                      f"p95={str(s['p95_per_vcpu_percent'])+'%' if s['samples'] else 'N/A'}")
        if not raw:
            print("WARNING: No metrics were returned. Check VM power state, permissions, interval and retention.")
        print(f"\nFiles written to: {output.resolve()}")
        return 0 if raw else 2
    finally:
        password = None
        if si:
            Disconnect(si)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (vmodl.MethodFault, Exception) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
